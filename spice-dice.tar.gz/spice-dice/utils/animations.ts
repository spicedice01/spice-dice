import { type Variants } from "framer-motion";

// ─── Easing Curves ──────────────────────────────────────────
export const EASING = {
  cinematic: [0.25, 0.1, 0.25, 1],
  outExpo: [0.16, 1, 0.3, 1],
  inOutQuart: [0.76, 0, 0.24, 1],
  spring: [0.34, 1.56, 0.64, 1],
} as const;

// ─── Fade Up (core reveal) ──────────────────────────────────
export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.9, ease: EASING.outExpo },
  },
};

// ─── Fade In ────────────────────────────────────────────────
export const fadeIn: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { duration: 0.7, ease: EASING.cinematic },
  },
};

// ─── Slide In from Left ─────────────────────────────────────
export const slideLeft: Variants = {
  hidden: { opacity: 0, x: -60 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.9, ease: EASING.outExpo },
  },
};

// ─── Slide In from Right ────────────────────────────────────
export const slideRight: Variants = {
  hidden: { opacity: 0, x: 60 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.9, ease: EASING.outExpo },
  },
};

// ─── Scale Up ───────────────────────────────────────────────
export const scaleUp: Variants = {
  hidden: { opacity: 0, scale: 0.85 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.8, ease: EASING.outExpo },
  },
};

// ─── Stagger Container ──────────────────────────────────────
export const staggerContainer: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
      delayChildren: 0.1,
    },
  },
};

// ─── Stagger Fast ───────────────────────────────────────────
export const staggerFast: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.07,
      delayChildren: 0.05,
    },
  },
};

// ─── Hero Title (letter by letter) ─────────────────────────
export const heroTitle: Variants = {
  hidden: { opacity: 0, y: 60, rotateX: 20 },
  visible: {
    opacity: 1,
    y: 0,
    rotateX: 0,
    transition: { duration: 1.2, ease: EASING.outExpo },
  },
};

// ─── Page Transition ────────────────────────────────────────
export const pageTransition: Variants = {
  initial: { opacity: 0, y: 20 },
  animate: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: EASING.outExpo },
  },
  exit: {
    opacity: 0,
    y: -20,
    transition: { duration: 0.4, ease: EASING.cinematic },
  },
};

// ─── Card Hover ─────────────────────────────────────────────
export const cardHover = {
  rest: { scale: 1, y: 0 },
  hover: {
    scale: 1.02,
    y: -6,
    transition: { duration: 0.35, ease: EASING.outExpo },
  },
};

// ─── Glow Pulse ─────────────────────────────────────────────
export const glowPulse = {
  animate: {
    scale: [1, 1.2, 1],
    opacity: [0.3, 0.6, 0.3],
    transition: {
      duration: 6,
      repeat: Infinity,
      ease: "easeInOut",
    },
  },
};

// ─── Float ──────────────────────────────────────────────────
export const floatAnimation = {
  animate: {
    y: [0, -16, 0],
    transition: {
      duration: 6,
      repeat: Infinity,
      ease: "easeInOut",
    },
  },
};

// ─── Reveal Viewport Defaults ───────────────────────────────
export const revealViewport = {
  once: true,
  amount: 0.2,
};

// ─── Navbar Scroll ──────────────────────────────────────────
export const navbarVariants: Variants = {
  top: {
    background: "rgba(11,11,15,0)",
    borderColor: "rgba(255,255,255,0)",
    backdropFilter: "blur(0px)",
  },
  scrolled: {
    background: "rgba(11,11,15,0.85)",
    borderColor: "rgba(255,255,255,0.06)",
    backdropFilter: "blur(20px)",
  },
};
