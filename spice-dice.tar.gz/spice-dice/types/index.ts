// ─── Project / Portfolio Types ─────────────────────────────
export interface Project {
  _id: string;
  _type: "project";
  title: string;
  slug: { current: string };
  category: ProjectCategory;
  thumbnail: SanityImage;
  heroImage: SanityImage;
  gallery: SanityImage[];
  videoUrl?: string;
  excerpt: string;
  description: any[]; // Portable Text
  client?: string;
  year: number;
  tools: string[];
  tags: string[];
  problem?: string;
  vision?: string;
  execution?: string;
  result?: string;
  impact?: string;
  metrics?: ProjectMetric[];
  testimonial?: Testimonial;
  featured: boolean;
  tier: 1 | 2 | 3;
  order: number;
}

export type ProjectCategory =
  | "short-film"
  | "branding"
  | "youtube"
  | "ai-project"
  | "social-campaign"
  | "graphic-design";

export interface ProjectMetric {
  label: string;
  value: string;
  change?: string;
}

// ─── AI Lab Types ───────────────────────────────────────────
export interface AILabEntry {
  _id: string;
  _type: "aiLabEntry";
  title: string;
  slug: { current: string };
  description: string;
  content: any[]; // Portable Text
  thumbnail: SanityImage;
  tags: string[];
  status: "live" | "experiment" | "concept";
  year: number;
  featured: boolean;
}

// ─── Service Types ──────────────────────────────────────────
export interface Service {
  _id: string;
  _type: "service";
  number: string;
  title: string;
  description: string;
  icon: string;
  tags: string[];
  price?: string;
  deliverables?: string[];
  order: number;
}

// ─── Testimonial Types ──────────────────────────────────────
export interface Testimonial {
  _id: string;
  _type: "testimonial";
  quote: string;
  author: string;
  role: string;
  company?: string;
  avatar?: SanityImage;
  featured: boolean;
  project?: { title: string; slug: { current: string } };
}

// ─── Blog Types ─────────────────────────────────────────────
export interface BlogPost {
  _id: string;
  _type: "blogPost";
  title: string;
  slug: { current: string };
  excerpt: string;
  content: any[]; // Portable Text
  thumbnail: SanityImage;
  category: BlogCategory;
  tags: string[];
  readTime: number;
  publishedAt: string;
  featured: boolean;
}

export type BlogCategory =
  | "ai-creativity"
  | "filmmaking"
  | "youtube-strategy"
  | "storytelling"
  | "digital-branding"
  | "creator-economy";

// ─── Sanity Types ───────────────────────────────────────────
export interface SanityImage {
  _type: "image";
  asset: { _ref: string; _type: "reference" };
  alt?: string;
  hotspot?: { x: number; y: number; height: number; width: number };
  crop?: { top: number; bottom: number; left: number; right: number };
}

// ─── Navigation Types ───────────────────────────────────────
export interface NavItem {
  label: string;
  href: string;
  external?: boolean;
}

// ─── Motion Types ───────────────────────────────────────────
export interface AnimationConfig {
  initial?: Record<string, unknown>;
  animate?: Record<string, unknown>;
  exit?: Record<string, unknown>;
  transition?: Record<string, unknown>;
  viewport?: { once?: boolean; amount?: number };
}

// ─── UI Types ───────────────────────────────────────────────
export type ThemeAccent = "purple" | "cyan" | "white";

export interface CTAButton {
  label: string;
  href: string;
  variant: "primary" | "secondary" | "cyan";
  icon?: string;
}

// ─── Page Metadata ──────────────────────────────────────────
export interface PageSEO {
  title: string;
  description: string;
  image?: string;
  keywords?: string[];
}
