"use client";
import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import Reveal from "@/components/ui/Reveal";
import { staggerContainer, fadeUp } from "@/utils/animations";

const TIMELINE = [
  { phase: "Phase 01", title: "The Beginning", text: "A journey fueled by curiosity, storytelling, and the hunger to create something meaningful from nothing." },
  { phase: "Phase 02", title: "Creative Discovery", text: "Exploring film, content, design, and digital culture as tools for expression, transformation, and artistic growth." },
  { phase: "Phase 03", title: "Digital Evolution", text: "Transforming ideas into visuals, campaigns, and experiences that connect with modern global audiences." },
  { phase: "Phase 04", title: "Entering the Future", text: "Blending AI, storytelling, and strategy to architect the next generation of immersive digital experiences." },
];

export default function StorySection() {
  return (
    <section className="py-32 relative">
      <div className="absolute right-0 top-0 bottom-0 w-1/2 bg-gradient-to-l from-bg-surface/20 to-transparent pointer-events-none" />
      <div className="section-container">
        <div className="grid lg:grid-cols-2 gap-20 items-start">
          {/* Left */}
          <Reveal>
            <div className="section-eyebrow">The Story</div>
            <h2 className="font-display text-section text-content-primary mb-6">
              FROM<br />GRASS TO<br />GRACE
            </h2>
            <p className="text-content-secondary leading-relaxed mb-4 max-w-sm">
              Every vision starts somewhere. Spice Dice was built from passion, resilience, and the belief that no dream is too big — regardless of the odds against you.
            </p>
            <p className="text-content-secondary leading-relaxed mb-10 max-w-sm">
              From grassroots beginnings to building cinematic digital experiences, the mission has always remained the same: to inspire, innovate, and create work that moves people.
            </p>
            <Link href="/about" className="btn btn-secondary gap-2">
              Full Story <ArrowUpRight size={16} />
            </Link>
          </Reveal>

          {/* Timeline */}
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            className="relative pl-8"
          >
            {/* Line */}
            <div className="absolute left-0 top-2 bottom-2 w-px bg-gradient-to-b from-accent-purple/60 via-accent-cyan/40 to-transparent" />

            {TIMELINE.map((item, i) => (
              <motion.div key={i} variants={fadeUp} className="relative mb-10 last:mb-0">
                {/* Dot */}
                <div className="absolute -left-8 top-1.5 w-3 h-3 rounded-full border-2 border-accent-purple bg-bg"
                  style={{ boxShadow: "0 0 10px rgba(124,58,237,0.5)" }}
                />
                <div className="text-[10px] tracking-[2px] text-accent-purple uppercase mb-2">{item.phase}</div>
                <h3 className="font-display text-xl text-content-primary mb-2">{item.title}</h3>
                <p className="text-content-secondary text-sm leading-relaxed">{item.text}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
