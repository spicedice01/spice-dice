"use client";

import { useRef, useEffect, useState } from "react";
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { ArrowDown, Play, ChevronRight } from "lucide-react";
import ParticleField from "@/components/ui/ParticleField";
import { staggerContainer, fadeUp, heroTitle, EASING } from "@/utils/animations";

const ROTATING_WORDS = [
  "Filmmaker",
  "Creative Strategist",
  "AI Innovator",
  "Digital Storyteller",
  "Visual Architect",
  "Brand Builder",
  "Future Creator",
];

const STATS = [
  { value: "40+", label: "Projects Delivered" },
  { value: "5+", label: "Years Creating" },
  { value: "2", label: "Markets Served" },
  { value: "6", label: "Service Verticals" },
];

export default function HeroSection() {
  const [wordIndex, setWordIndex] = useState(0);
  const [showWord, setShowWord] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "40%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.6], [1, 0]);

  // Rotating words
  useEffect(() => {
    const timeout = setTimeout(() => {
      setShowWord(false);
      setTimeout(() => {
        setWordIndex((i) => (i + 1) % ROTATING_WORDS.length);
        setShowWord(true);
      }, 300);
    }, 2500);
    return () => clearTimeout(timeout);
  }, [wordIndex]);

  return (
    <section
      ref={containerRef}
      className="relative min-h-screen flex flex-col overflow-hidden"
    >
      {/* ── Background System ─────────────────────────── */}
      <div className="absolute inset-0 z-0">
        {/* Grid */}
        <div className="absolute inset-0 cinematic-grid opacity-40" />

        {/* Particles */}
        <ParticleField count={50} />

        {/* Glow orbs */}
        <motion.div
          animate={{ scale: [1, 1.3, 1], opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -top-40 -left-40 w-[700px] h-[700px] bg-accent-purple/15 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ scale: [1, 1.2, 1], opacity: [0.1, 0.25, 0.1] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 3 }}
          className="absolute top-20 -right-32 w-[500px] h-[500px] bg-accent-cyan/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ scale: [1, 1.4, 1], opacity: [0.15, 0.3, 0.15] }}
          transition={{ duration: 12, repeat: Infinity, ease: "easeInOut", delay: 6 }}
          className="absolute bottom-0 left-1/3 w-[400px] h-[400px] bg-accent-purple/10 rounded-full blur-3xl"
        />

        {/* Scan line */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div
            className="absolute w-full h-px bg-gradient-to-r from-transparent via-accent-cyan/10 to-transparent"
            style={{ animation: "scanLine 8s linear infinite" }}
          />
        </div>
      </div>

      {/* ── Main Content ──────────────────────────────── */}
      <motion.div
        style={{ y, opacity }}
        className="relative z-10 flex-1 flex items-center"
      >
        <div className="section-container w-full pt-32 pb-20">
          <div className="grid lg:grid-cols-2 gap-16 items-center">

            {/* Left: Text */}
            <motion.div
              variants={staggerContainer}
              initial="hidden"
              animate="visible"
              className="max-w-2xl"
            >
              {/* Eyebrow */}
              <motion.div variants={fadeUp} className="flex items-center gap-3 mb-8">
                <div className="w-8 h-px bg-accent-purple" />
                <span className="text-[11px] tracking-[3px] text-accent-purple uppercase font-medium">
                  Creative Technologist · Digital Media Architect
                </span>
              </motion.div>

              {/* Headline */}
              <motion.div variants={heroTitle} className="mb-6">
                <h1 className="font-display leading-none tracking-tight">
                  <span className="block text-hero-xl text-content-primary">
                    BUILDING
                  </span>
                  <span className="block text-hero-xl text-gradient mt-1">
                    STORIES,
                  </span>
                  <span className="block text-hero-xl text-content-primary mt-1">
                    BRANDS &
                  </span>
                  <span className="block text-hero-xl text-gradient-cyan mt-1">
                    DIGITAL
                  </span>
                  <span className="block text-hero-xl text-content-primary mt-1">
                    EXPERIENCES
                  </span>
                </h1>
              </motion.div>

              {/* Rotating word */}
              <motion.div variants={fadeUp} className="flex items-center gap-3 mb-6 h-8">
                <span className="text-xs tracking-[2px] text-content-muted uppercase">currently:</span>
                <AnimatePresence mode="wait">
                  {showWord && (
                    <motion.span
                      key={wordIndex}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8 }}
                      transition={{ duration: 0.3, ease: EASING.outExpo }}
                      className="text-sm font-medium text-accent-cyan tracking-wide"
                    >
                      {ROTATING_WORDS[wordIndex]}
                    </motion.span>
                  )}
                </AnimatePresence>
              </motion.div>

              {/* Subheading */}
              <motion.p
                variants={fadeUp}
                className="text-content-secondary text-base leading-relaxed max-w-lg mb-10"
              >
                Spice Dice is a cinematic creative collective blending storytelling, AI, strategy, and digital innovation for the next generation of digital culture.
              </motion.p>

              {/* CTA Buttons */}
              <motion.div variants={fadeUp} className="flex flex-wrap gap-4">
                <Link href="/contact" className="btn btn-primary gap-2">
                  Book Consultation
                  <ChevronRight size={16} />
                </Link>
                <button className="btn btn-secondary gap-2 group">
                  <div className="w-8 h-8 rounded-full bg-accent-purple/20 flex items-center justify-center group-hover:bg-accent-purple/40 transition-colors">
                    <Play size={12} fill="currentColor" className="text-accent-purple ml-0.5" />
                  </div>
                  Watch Showreel
                </button>
                <Link href="/portfolio" className="btn btn-secondary">
                  View Portfolio
                </Link>
              </motion.div>
            </motion.div>

            {/* Right: Visual Cards */}
            <motion.div
              initial={{ opacity: 0, x: 60 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.5, ease: EASING.outExpo }}
              className="hidden lg:grid grid-cols-2 gap-4"
            >
              {/* Status card */}
              <motion.div
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                className="glass-purple rounded-2xl p-6"
              >
                <div className="text-[10px] tracking-[2px] text-accent-purple uppercase mb-3">Status</div>
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                  <span className="text-sm font-medium">Available</span>
                </div>
                <div className="text-xs text-content-muted">for new projects</div>
              </motion.div>

              {/* Projects card */}
              <motion.div
                animate={{ y: [0, -12, 0] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                className="glass rounded-2xl p-6"
              >
                <div className="text-[10px] tracking-[2px] text-content-muted uppercase mb-3">Projects</div>
                <div className="font-display text-4xl text-gradient">40+</div>
                <div className="text-xs text-content-muted mt-1">delivered globally</div>
              </motion.div>

              {/* Tags card */}
              <motion.div
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 2 }}
                className="col-span-2 glass rounded-2xl p-6"
              >
                <div className="text-[10px] tracking-[2px] text-content-muted uppercase mb-4">Expertise</div>
                <div className="flex flex-wrap gap-2">
                  {["Cinematic Film", "AI Systems", "Brand Strategy", "YouTube Growth", "Digital Design", "Creative Direction"].map((tag) => (
                    <span key={tag} className="tag tag-purple">{tag}</span>
                  ))}
                </div>
              </motion.div>

              {/* From Grass to Grace */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 3 }}
                className="col-span-2 glass-cyan rounded-2xl p-6"
              >
                <div className="text-[10px] tracking-[2px] text-accent-cyan uppercase mb-2">Core Narrative</div>
                <div className="font-display text-lg text-gradient-cyan">From Grass to Grace</div>
                <div className="text-xs text-content-secondary mt-2 leading-relaxed">
                  Building a world-class digital brand from grassroots origins through resilience, creativity, and vision.
                </div>
              </motion.div>
            </motion.div>
          </div>

          {/* Stats row */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1, ease: EASING.outExpo }}
            className="grid grid-cols-2 md:grid-cols-4 gap-px bg-border-subtle mt-20 rounded-2xl overflow-hidden"
          >
            {STATS.map((stat) => (
              <div key={stat.label} className="bg-bg-surface px-6 py-5 text-center">
                <div className="font-display text-3xl text-gradient-full mb-1">{stat.value}</div>
                <div className="text-xs text-content-muted tracking-wide">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="relative z-10 flex justify-center pb-10"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="flex flex-col items-center gap-2 text-content-muted"
        >
          <span className="text-[10px] tracking-[3px] uppercase">Scroll</span>
          <ArrowDown size={14} />
        </motion.div>
      </motion.div>
    </section>
  );
}
