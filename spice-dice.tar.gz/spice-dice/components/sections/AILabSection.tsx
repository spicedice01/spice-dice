"use client";
import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import Reveal from "@/components/ui/Reveal";
import { staggerContainer, fadeUp } from "@/utils/animations";

const EXPERIMENTS = [
  {
    id: 1,
    label: "Experiment 01",
    title: "AI Visual Storytelling Engine",
    desc: "A system that merges cinematic direction with generative AI to produce emotionally intelligent visual narratives.",
    status: "Live",
    tags: ["Generative AI", "Narrative Systems", "Visual Intelligence"],
    wide: true,
  },
  {
    id: 2,
    label: "Experiment 02",
    title: "Creative Automation",
    desc: "AI-powered production workflows that accelerate creative output without sacrificing artistic vision.",
    status: "Experiment",
    tags: ["Automation", "Production"],
    wide: false,
  },
  {
    id: 3,
    label: "Experiment 03",
    title: "Future Experience Concepts",
    desc: "Futuristic interfaces and immersive systems that reimagine how audiences interact with creative content.",
    status: "Concept",
    tags: ["UX", "Futurism"],
    wide: false,
  },
  {
    id: 4,
    label: "Experiment 04",
    title: "Cinematic AI Research",
    desc: "Exploring how AI can assist in cinematic pre-production — from script analysis to visual mood generation.",
    status: "Experiment",
    tags: ["Research", "Cinema", "Pre-production"],
    wide: true,
  },
];

const statusColor: Record<string, string> = {
  Live: "bg-green-400",
  Experiment: "bg-accent-cyan",
  Concept: "bg-accent-purple",
};

export default function AILabSection() {
  return (
    <section className="py-32 relative overflow-hidden">
      {/* Distinct background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-950/10 to-transparent" />
      <div className="absolute inset-0 cinematic-grid opacity-20" />

      {/* Animated neural grid */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 6 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-px bg-gradient-to-b from-transparent via-accent-cyan/10 to-transparent"
            style={{ left: `${15 + i * 14}%`, height: "100%" }}
            animate={{ opacity: [0.3, 0.7, 0.3] }}
            transition={{ duration: 3 + i * 0.7, repeat: Infinity, delay: i * 0.4 }}
          />
        ))}
      </div>

      <div className="section-container relative">
        <Reveal>
          <div className="section-eyebrow" style={{ color: "#00D4FF" }}>
            <span className="w-6 h-px bg-accent-cyan block" />
            AI Lab
          </div>
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16">
            <h2 className="font-display text-section text-content-primary">
              FUTURE<br />SYSTEMS
            </h2>
            <div className="max-w-xs">
              <p className="text-content-secondary text-sm leading-relaxed mb-4">
                Exploring the frontier of storytelling through artificial intelligence and experimental digital systems.
              </p>
              <Link href="/ai-lab" className="btn btn-secondary gap-2 text-sm border-accent-cyan/20 hover:border-accent-cyan/50">
                Explore the Lab <ArrowUpRight size={14} />
              </Link>
            </div>
          </div>
        </Reveal>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          className="grid md:grid-cols-2 gap-4"
        >
          {EXPERIMENTS.map((exp) => (
            <motion.div
              key={exp.id}
              variants={fadeUp}
              className={`glass-cyan rounded-2xl p-8 group cursor-pointer relative overflow-hidden ${exp.wide ? "md:col-span-2" : ""}`}
            >
              {/* Animated glow */}
              <motion.div
                animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.6, 0.3] }}
                transition={{ duration: 4 + exp.id, repeat: Infinity }}
                className="absolute -top-12 -right-12 w-48 h-48 bg-accent-cyan/8 rounded-full blur-3xl"
              />

              <div className="relative">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[10px] tracking-[3px] text-accent-cyan uppercase">{exp.label}</span>
                  <div className="flex items-center gap-2">
                    <div className={`w-1.5 h-1.5 rounded-full ${statusColor[exp.status]} animate-pulse`} />
                    <span className="text-[10px] text-content-muted">{exp.status}</span>
                  </div>
                </div>

                <h3 className={`font-display text-content-primary mb-3 ${exp.wide ? "text-2xl" : "text-xl"}`}>
                  {exp.title}
                </h3>
                <p className="text-content-secondary text-sm leading-relaxed mb-6">{exp.desc}</p>

                <div className="flex flex-wrap gap-2">
                  {exp.tags.map((tag) => (
                    <span key={tag} className="tag tag-cyan text-[10px]">{tag}</span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
