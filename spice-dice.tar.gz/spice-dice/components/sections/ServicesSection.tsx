"use client";
import { motion } from "framer-motion";
import { staggerContainer, fadeUp } from "@/utils/animations";
import Reveal from "@/components/ui/Reveal";

const SERVICES = [
  {
    num: "01",
    title: "Creative Strategy & Direction",
    desc: "Developing powerful creative concepts, visual identity systems, and storytelling frameworks that position brands for modern audiences.",
    tags: ["Brand Identity", "Storytelling", "Campaign Direction"],
  },
  {
    num: "02",
    title: "AI Integration",
    desc: "Helping creators and businesses integrate AI-powered workflows, creative automation, and future-ready digital systems.",
    tags: ["AI Workflows", "Automation", "Future Systems"],
  },
  {
    num: "03",
    title: "Video Editing",
    desc: "Crafting cinematic edits, storytelling visuals, and immersive content experiences that capture attention instantly.",
    tags: ["Cinematic Edit", "Color Grading", "Sound Design"],
  },
  {
    num: "04",
    title: "YouTube Strategy",
    desc: "Building content systems focused on audience growth, retention, storytelling, and creator brand development.",
    tags: ["Audience Growth", "Retention", "Content Architecture"],
  },
  {
    num: "05",
    title: "Social Media Campaigns",
    desc: "Designing high-engagement campaigns built for attention, culture, and audience connection across modern platforms.",
    tags: ["Campaign Design", "Platform Strategy", "Engagement"],
  },
  {
    num: "06",
    title: "Digital Marketing",
    desc: "Combining creativity and strategy to build campaigns that increase visibility, engagement, and digital growth.",
    tags: ["Growth Strategy", "Analytics", "Conversion"],
  },
];

export default function ServicesSection() {
  return (
    <section className="py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-bg-surface/30 to-transparent pointer-events-none" />
      <div className="section-container relative">
        <Reveal>
          <div className="section-eyebrow">Services</div>
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16">
            <h2 className="font-display text-section text-content-primary">
              WHAT I BUILD
            </h2>
            <p className="text-content-secondary text-sm max-w-xs leading-relaxed">
              Creative systems designed to help brands, creators, and businesses grow through storytelling and digital innovation.
            </p>
          </div>
        </Reveal>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {SERVICES.map((s, i) => (
            <motion.div
              key={s.num}
              variants={fadeUp}
              custom={i}
              className="card-glass p-8 group cursor-pointer relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-accent-purple/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="relative">
                <div className="text-[11px] tracking-[3px] text-accent-purple mb-5">{s.num}</div>
                <h3 className="font-display text-xl text-content-primary mb-3 group-hover:text-gradient transition-all duration-300">
                  {s.title}
                </h3>
                <p className="text-content-secondary text-sm leading-relaxed mb-6">{s.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {s.tags.map((tag) => (
                    <span key={tag} className="tag tag-purple text-[10px]">{tag}</span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <Reveal delay={0.3} className="mt-12 text-center">
          <a href="/contact" className="btn btn-primary">
            Start a Project
          </a>
        </Reveal>
      </div>
    </section>
  );
}
