"use client";
import { motion } from "framer-motion";
import Link from "next/link";
import { MessageSquare, Calendar, ArrowRight } from "lucide-react";
import Reveal from "@/components/ui/Reveal";
import { staggerContainer, fadeUp } from "@/utils/animations";

const TESTIMONIALS = [
  {
    quote: "Creative, visionary, and highly innovative. Spice Dice brings cinematic energy and strategic intelligence into every single project. The results exceeded every expectation.",
    author: "James M.",
    role: "Brand Director",
    company: "Digital Collective",
    initials: "JM",
  },
  {
    quote: "Working with Spice Dice completely elevated our digital presence. The storytelling quality is world-class — the kind of work you usually only see from major international agencies.",
    author: "Amara N.",
    role: "Content Creator",
    company: "Independent",
    initials: "AN",
  },
  {
    quote: "The level of creativity and understanding of digital culture is rare. Spice Dice doesn't just deliver content — they transform your entire brand vision into something unforgettable.",
    author: "David K.",
    role: "Founder",
    company: "Tech Startup",
    initials: "DK",
  },
];

export function TestimonialsSection() {
  return (
    <section className="py-32">
      <div className="section-container">
        <Reveal>
          <div className="section-eyebrow">Voices</div>
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16">
            <h2 className="font-display text-section text-content-primary">COLLABORATIONS</h2>
            <p className="text-content-secondary text-sm max-w-xs leading-relaxed">
              Experiences shared by collaborators, creators, brands, and visionaries.
            </p>
          </div>
        </Reveal>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          className="grid md:grid-cols-3 gap-4"
        >
          {TESTIMONIALS.map((t, i) => (
            <motion.div key={i} variants={fadeUp} className="card-glass p-8 flex flex-col gap-6">
              <div className="text-content-secondary text-sm leading-relaxed italic flex-1">
                &ldquo;{t.quote}&rdquo;
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full glass-purple flex items-center justify-center text-xs font-semibold text-accent-purple border border-accent-purple/20">
                  {t.initials}
                </div>
                <div>
                  <div className="text-sm font-medium text-content-primary">{t.author}</div>
                  <div className="text-xs text-content-muted">{t.role}{t.company ? ` · ${t.company}` : ""}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

export function ContactCTASection() {
  return (
    <section className="py-32 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-accent-purple/8 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[400px] h-[400px] bg-accent-cyan/5 rounded-full blur-3xl" />
      </div>

      <div className="section-container relative text-center">
        <Reveal>
          <div className="section-eyebrow justify-center">Let&apos;s Create</div>
          <h2 className="font-display text-hero-lg text-gradient-full mt-4 mb-6">
            LET&apos;S BUILD SOMETHING<br />POWERFUL TOGETHER
          </h2>
          <p className="text-content-secondary text-base max-w-lg mx-auto leading-relaxed mb-12">
            Whether it&apos;s a brand, campaign, film, or digital experience — let&apos;s create something meaningful that stands out.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/contact" className="btn btn-primary text-base py-4 px-8 gap-2">
              Book Consultation
              <Calendar size={16} />
            </Link>
            <a
              href="https://wa.me/254000000000"
              target="_blank"
              rel="noopener noreferrer"
              className="btn text-base py-4 px-8 gap-2"
              style={{ background: "#25D366", color: "#fff" }}
            >
              <MessageSquare size={16} />
              Chat on WhatsApp
            </a>
            <Link href="/portfolio" className="btn btn-secondary text-base py-4 px-8 gap-2">
              View Portfolio
              <ArrowRight size={16} />
            </Link>
          </div>

          <p className="text-content-muted text-xs mt-8">
            Typically responds within 24 hours.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
