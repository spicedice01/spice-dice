"use client";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import Reveal from "@/components/ui/Reveal";
import { staggerContainer, fadeUp } from "@/utils/animations";

const CATEGORIES = ["All", "Short Film", "Branding", "YouTube", "AI Project", "Social Campaign", "Graphic Design"];

const PROJECTS = [
  { id: 1, title: "Youth Voices", category: "Short Film", year: "2024", gradient: "from-purple-900 via-purple-700 to-indigo-900", desc: "A cinematic documentary exploring the power of Gen Z storytelling." },
  { id: 2, title: "Future Frames", category: "AI Project", year: "2024", gradient: "from-cyan-900 via-teal-700 to-blue-900", desc: "AI-generated visual experiments pushing the boundaries of cinematic art." },
  { id: 3, title: "Brand Ignite", category: "Branding", year: "2024", gradient: "from-orange-900 via-red-800 to-pink-900", desc: "Visual identity system and brand strategy for a digital-native startup." },
  { id: 4, title: "Culture Shift", category: "Social Campaign", year: "2023", gradient: "from-green-900 via-emerald-700 to-teal-900", desc: "A cross-platform campaign connecting modern youth culture with digital storytelling." },
  { id: 5, title: "Channel Growth", category: "YouTube", year: "2023", gradient: "from-yellow-900 via-amber-700 to-orange-900", desc: "YouTube strategy system that scaled a creator's audience by 300%." },
  { id: 6, title: "Poster Systems", category: "Graphic Design", year: "2023", gradient: "from-rose-900 via-pink-700 to-fuchsia-900", desc: "Motion-informed poster design system for cultural events and campaigns." },
  { id: 7, title: "Digital Nomad", category: "Short Film", year: "2023", gradient: "from-blue-900 via-indigo-700 to-violet-900", desc: "A cinematic short documenting creative life across digital borders." },
  { id: 8, title: "AI Studio", category: "AI Project", year: "2024", gradient: "from-slate-900 via-cyan-800 to-blue-800", desc: "An AI-powered creative workflow system for modern production studios." },
  { id: 9, title: "Sonic Brand", category: "Branding", year: "2024", gradient: "from-violet-900 via-purple-700 to-fuchsia-800", desc: "Full brand identity and sonic branding for an African music collective." },
];

export default function PortfolioSection() {
  const [active, setActive] = useState("All");

  const filtered = active === "All" ? PROJECTS : PROJECTS.filter((p) => p.category === active);

  return (
    <section className="py-32 relative">
      <div className="section-container">
        <Reveal>
          <div className="section-eyebrow">Selected Work</div>
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
            <h2 className="font-display text-section text-content-primary">PORTFOLIO</h2>
            <Link href="/portfolio" className="btn btn-secondary gap-2 text-sm">
              View All Work <ArrowUpRight size={14} />
            </Link>
          </div>
        </Reveal>

        {/* Filters */}
        <Reveal delay={0.1}>
          <div className="flex flex-wrap gap-2 mb-12">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActive(cat)}
                className={`px-4 py-2 rounded-full text-xs font-medium tracking-wide transition-all duration-300 ${
                  active === cat
                    ? "bg-accent-purple text-white"
                    : "glass text-content-secondary hover:text-content-primary border-border-subtle"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </Reveal>

        {/* Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            {filtered.map((project, i) => (
              <motion.div
                key={project.id}
                variants={fadeUp}
                layout
                className="group cursor-pointer rounded-2xl overflow-hidden border border-border-subtle hover:border-accent/30 transition-all duration-500"
              >
                {/* Thumbnail */}
                <div className={`relative h-52 bg-gradient-to-br ${project.gradient} overflow-hidden`}>
                  <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors duration-500" />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="w-12 h-12 rounded-full glass flex items-center justify-center border border-white/20">
                      <ArrowUpRight size={18} className="text-white" />
                    </div>
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <span className="tag tag-purple text-[10px]">{project.category}</span>
                  </div>
                </div>
                {/* Info */}
                <div className="p-5 bg-bg-surface">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-display text-lg text-content-primary group-hover:text-gradient transition-all duration-300">
                      {project.title}
                    </h3>
                    <span className="text-xs text-content-muted mt-1">{project.year}</span>
                  </div>
                  <p className="text-content-secondary text-xs leading-relaxed">{project.desc}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
}
