"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

export default function CustomCursor() {
  const dotX = useMotionValue(-100);
  const dotY = useMotionValue(-100);
  const ringX = useSpring(useMotionValue(-100), { damping: 25, stiffness: 300 });
  const ringY = useSpring(useMotionValue(-100), { damping: 25, stiffness: 300 });
  const [hovering, setHovering] = useState(false);
  const [clicking, setClicking] = useState(false);
  const dotXRef = useRef(dotX);
  const dotYRef = useRef(dotY);

  useEffect(() => {
    const handleMove = (e: MouseEvent) => {
      dotXRef.current.set(e.clientX);
      dotYRef.current.set(e.clientY);
      (ringX as any).set(e.clientX);
      (ringY as any).set(e.clientY);
    };

    const handleHoverStart = (e: Event) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === "A" ||
        target.tagName === "BUTTON" ||
        target.closest("a") ||
        target.closest("button") ||
        target.dataset.cursor === "hover"
      ) {
        setHovering(true);
      }
    };

    const handleHoverEnd = () => setHovering(false);
    const handleMouseDown = () => setClicking(true);
    const handleMouseUp = () => setClicking(false);

    window.addEventListener("mousemove", handleMove);
    window.addEventListener("mouseover", handleHoverStart);
    window.addEventListener("mouseout", handleHoverEnd);
    window.addEventListener("mousedown", handleMouseDown);
    window.addEventListener("mouseup", handleMouseUp);

    return () => {
      window.removeEventListener("mousemove", handleMove);
      window.removeEventListener("mouseover", handleHoverStart);
      window.removeEventListener("mouseout", handleHoverEnd);
      window.removeEventListener("mousedown", handleMouseDown);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [ringX, ringY]);

  return (
    <>
      {/* Dot */}
      <motion.div
        className="fixed top-0 left-0 z-[9999] pointer-events-none hidden md:block"
        style={{
          x: dotX,
          y: dotY,
          translateX: "-50%",
          translateY: "-50%",
        }}
      >
        <motion.div
          animate={{
            width: hovering ? 0 : clicking ? 3 : 6,
            height: hovering ? 0 : clicking ? 3 : 6,
            backgroundColor: hovering ? "#00D4FF" : "#00D4FF",
          }}
          transition={{ duration: 0.15 }}
          className="rounded-full"
        />
      </motion.div>

      {/* Ring */}
      <motion.div
        className="fixed top-0 left-0 z-[9998] pointer-events-none hidden md:block"
        style={{
          x: ringX,
          y: ringY,
          translateX: "-50%",
          translateY: "-50%",
        }}
      >
        <motion.div
          animate={{
            width: hovering ? 52 : clicking ? 28 : 36,
            height: hovering ? 52 : clicking ? 28 : 36,
            borderColor: hovering
              ? "rgba(124,58,237,0.8)"
              : "rgba(124,58,237,0.4)",
            rotate: clicking ? 45 : 0,
          }}
          transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="rounded-full border"
        />
      </motion.div>
    </>
  );
}
