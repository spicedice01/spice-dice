"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Preloader() {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState(0);

  const phases = [
    "INITIALIZING CREATIVE SYSTEMS...",
    "LOADING CINEMATIC LAYERS...",
    "BUILDING DIGITAL UNIVERSE...",
    "SPICE DICE",
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => setLoading(false), 400);
          return 100;
        }
        return prev + Math.random() * 8 + 2;
      });
    }, 60);

    const phaseInterval = setInterval(() => {
      setPhase((prev) => Math.min(prev + 1, phases.length - 1));
    }, 600);

    return () => {
      clearInterval(interval);
      clearInterval(phaseInterval);
    };
  }, []);

  return (
    <AnimatePresence>
      {loading && (
        <motion.div
          key="preloader"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.02 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="fixed inset-0 z-[500] flex flex-col items-center justify-center bg-bg"
        >
          {/* Background grid */}
          <div className="absolute inset-0 cinematic-grid opacity-30" />

          {/* Glow orbs */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent-purple/5 rounded-full blur-3xl animate-pulse-glow" />

          {/* Content */}
          <div className="relative flex flex-col items-center gap-12 w-full max-w-sm px-8">
            {/* Logo animation */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="text-center"
            >
              <div className="font-display text-5xl tracking-[8px] text-gradient mb-3">
                SD
              </div>
              <div className="text-[10px] tracking-[4px] text-content-secondary uppercase">
                CREATIVE SYSTEMS
              </div>
            </motion.div>

            {/* Phase text */}
            <AnimatePresence mode="wait">
              <motion.div
                key={phase}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.4 }}
                className={`text-[10px] tracking-[3px] ${
                  phase === phases.length - 1
                    ? "text-accent-purple font-display text-2xl tracking-[6px]"
                    : "text-content-muted uppercase"
                }`}
              >
                {phases[phase]}
              </motion.div>
            </AnimatePresence>

            {/* Progress bar */}
            <div className="w-full">
              <div className="h-[1px] bg-bg-elevated rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-accent-purple to-accent-cyan"
                  initial={{ width: "0%" }}
                  animate={{ width: `${Math.min(progress, 100)}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
              <div className="flex justify-between mt-2 text-[10px] text-content-muted font-mono">
                <span>LOADING</span>
                <span>{Math.min(Math.round(progress), 100)}%</span>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
