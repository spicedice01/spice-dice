import Link from "next/link";
import { ArrowUpRight } from "lucide-react";

const LINKS = {
  explore: [
    { label: "Story", href: "/about" },
    { label: "Services", href: "/services" },
    { label: "Portfolio", href: "/portfolio" },
    { label: "AI Lab", href: "/ai-lab" },
    { label: "Blog", href: "/blog" },
  ],
  connect: [
    { label: "Contact", href: "/contact" },
    { label: "Book Consultation", href: "/booking" },
    { label: "WhatsApp", href: "https://wa.me/254000000000", external: true },
  ],
  social: [
    { label: "YouTube", href: "#", external: true },
    { label: "Instagram", href: "#", external: true },
    { label: "TikTok", href: "#", external: true },
    { label: "LinkedIn", href: "#", external: true },
  ],
};

export default function Footer() {
  return (
    <footer className="relative border-t border-border-subtle">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-bg-surface/30 to-transparent" />

      <div className="relative section-container py-20">
        {/* Top row */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-16 mb-20">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="font-display text-3xl tracking-[6px] text-gradient mb-4">
              SPICE DICE
            </div>
            <p className="text-content-secondary text-sm leading-relaxed max-w-xs mb-8">
              A cinematic creative technologist building immersive digital experiences through storytelling, AI, strategy, and visual innovation.
            </p>
            <div className="text-xs tracking-[2px] text-accent-purple uppercase">
              From Grass to Grace
            </div>
          </div>

          {/* Links */}
          {Object.entries(LINKS).map(([key, items]) => (
            <div key={key}>
              <div className="section-eyebrow text-[10px] mb-6">
                {key.charAt(0).toUpperCase() + key.slice(1)}
              </div>
              <ul className="space-y-3">
                {items.map((item) => (
                  <li key={item.label}>
                    <Link
                      href={item.href}
                      target={(item as any).external ? "_blank" : undefined}
                      rel={(item as any).external ? "noopener noreferrer" : undefined}
                      className="flex items-center gap-1.5 text-sm text-content-secondary hover:text-content-primary transition-colors group"
                    >
                      {item.label}
                      {(item as any).external && (
                        <ArrowUpRight
                          size={12}
                          className="opacity-0 group-hover:opacity-100 transition-opacity"
                        />
                      )}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Divider */}
        <div className="divider mb-8" />

        {/* Bottom row */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-content-muted">
          <div>© 2026 Spice Dice. Crafted for the future of storytelling.</div>
          <div className="italic text-accent-purple/70">
            "Crafting Digital Futures Through Storytelling & Innovation"
          </div>
        </div>
      </div>
    </footer>
  );
}
