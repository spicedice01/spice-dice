import HeroSection from "@/components/sections/HeroSection";
import StorySection from "@/components/sections/StorySection";
import ServicesSection from "@/components/sections/ServicesSection";
import PortfolioSection from "@/components/sections/PortfolioSection";
import AILabSection from "@/components/sections/AILabSection";
import { TestimonialsSection, ContactCTASection } from "@/components/sections/TestimonialsAndCTA";

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <div className="divider" />
      <StorySection />
      <div className="divider" />
      <ServicesSection />
      <div className="divider" />
      <PortfolioSection />
      <div className="divider" />
      <AILabSection />
      <div className="divider" />
      <TestimonialsSection />
      <div className="divider" />
      <ContactCTASection />
    </>
  );
}
