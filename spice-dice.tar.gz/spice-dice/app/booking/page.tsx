import type { Metadata } from "next";
import Link from "next/link";
import { Calendar, Clock, Video, MessageSquare } from "lucide-react";

export const metadata: Metadata = {
  title: "Book a Consultation",
  description: "Schedule a free consultation to discuss your creative project with Spice Dice.",
};

const OPTIONS = [
  { icon: Video, title: "Discovery Call", duration: "30 min", desc: "A quick intro call to discuss your project, goals, and how we can work together.", cta: "Book Call" },
  { icon: Calendar, title: "Strategy Session", duration: "60 min", desc: "A deep-dive session to map out a full creative strategy for your brand or campaign.", cta: "Book Session" },
  { icon: MessageSquare, title: "WhatsApp Inquiry", duration: "Async", desc: "Send a message on WhatsApp for quick questions, pricing inquiries, or to get the ball rolling.", cta: "Open WhatsApp" },
];

export default function BookingPage() {
  return (
    <div className="pt-32 pb-20">
      <div className="section-container">
        <div className="section-eyebrow mb-6">Book</div>
        <h1 className="font-display text-hero-lg text-gradient mb-8">BOOK A<br />CONSULTATION</h1>
        <p className="text-content-secondary text-lg max-w-xl mb-16 leading-relaxed">
          Choose the format that works best for you. All consultations are free — no commitments, just a conversation about your vision.
        </p>

        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {OPTIONS.map((opt) => (
            <div key={opt.title} className="card-glass p-8 flex flex-col">
              <div className="w-12 h-12 rounded-2xl glass-purple flex items-center justify-center mb-6">
                <opt.icon size={20} className="text-accent-purple" />
              </div>
              <div className="flex items-center gap-3 mb-3">
                <h2 className="font-display text-xl text-content-primary">{opt.title}</h2>
              </div>
              <div className="flex items-center gap-2 mb-4">
                <Clock size={12} className="text-content-muted" />
                <span className="text-xs text-content-muted">{opt.duration}</span>
              </div>
              <p className="text-content-secondary text-sm leading-relaxed mb-8 flex-1">{opt.desc}</p>
              <button className="btn btn-primary w-full justify-center">{opt.cta}</button>
            </div>
          ))}
        </div>

        {/* Calendly placeholder */}
        <div className="card-glass rounded-3xl p-12 text-center">
          <h2 className="font-display text-2xl text-content-primary mb-4">Schedule Directly</h2>
          <p className="text-content-secondary text-sm mb-8 max-w-md mx-auto">Connect your Calendly or preferred booking system here. For now, reach out via the contact page or WhatsApp to schedule.</p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link href="/contact" className="btn btn-primary">Go to Contact</Link>
            <a href="https://wa.me/254000000000" target="_blank" rel="noopener noreferrer"
              className="btn text-sm" style={{ background: "#25D366", color: "#fff" }}>
              WhatsApp
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
