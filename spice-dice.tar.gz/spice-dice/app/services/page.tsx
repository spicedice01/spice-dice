import type { Metadata } from "next";
import Link from "next/link";
import { ChevronRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Services — Creative Strategy, Film, AI & More",
  description: "Creative strategy, AI integration, video editing, YouTube growth, social campaigns, and digital marketing — built for modern brands.",
};

const SERVICES = [
  { num: "01", title: "Creative Strategy & Direction", desc: "Developing powerful creative concepts, visual identity systems, and storytelling frameworks that position brands for modern audiences. Every campaign starts with strategy.", deliverables: ["Brand Identity System", "Campaign Strategy", "Visual Direction", "Content Architecture", "Creative Briefs"], for: "Brands, Startups, SMEs" },
  { num: "02", title: "AI Integration", desc: "Helping creators and businesses integrate AI-powered workflows, creative automation, and future-ready digital systems that accelerate production without sacrificing quality.", deliverables: ["AI Workflow Design", "Creative Automation", "Tool Integration", "Process Optimization", "AI-assisted Production"], for: "Studios, Creators, Tech Companies" },
  { num: "03", title: "Video Editing", desc: "Crafting cinematic edits, storytelling visuals, and immersive content experiences that capture attention instantly and hold it through the power of narrative.", deliverables: ["Cinematic Edit", "Color Grading", "Sound Design", "Motion Graphics", "Final Delivery"], for: "Brands, Content Creators, Events" },
  { num: "04", title: "YouTube Strategy", desc: "Building content systems focused on audience growth, retention optimization, storytelling formats, and creator brand development that compounds over time.", deliverables: ["Channel Strategy", "Content Calendar", "Thumbnail Design", "Retention System", "Growth Analytics"], for: "YouTubers, Media Companies, Brands" },
  { num: "05", title: "Social Media Campaigns", desc: "Designing high-engagement campaigns built for attention, culture, and audience connection — crafted specifically for the platform and audience they'll reach.", deliverables: ["Campaign Strategy", "Content Production", "Platform Optimization", "Performance Tracking", "Audience Analysis"], for: "SMEs, Brands, Influencers" },
  { num: "06", title: "Digital Marketing", desc: "Combining creativity and strategy to build campaigns that increase visibility, engagement, and digital growth through data-informed creative execution.", deliverables: ["Marketing Strategy", "Campaign Execution", "Analytics & Reporting", "Conversion Optimization", "Growth Planning"], for: "Businesses, E-commerce, Startups" },
];

export default function ServicesPage() {
  return (
    <div className="pt-32 pb-20">
      <div className="section-container">
        <div className="section-eyebrow mb-6">Services</div>
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-8 mb-20">
          <h1 className="font-display text-hero-lg text-content-primary">WHAT<br />I BUILD</h1>
          <p className="text-content-secondary text-base max-w-sm leading-relaxed">
            Creative systems designed to help brands, creators, and businesses grow through storytelling, strategy, and digital innovation. Pricing revealed after consultation.
          </p>
        </div>

        <div className="space-y-4">
          {SERVICES.map((s) => (
            <div key={s.num} className="card-glass p-8 md:p-10 group">
              <div className="grid md:grid-cols-3 gap-8">
                <div className="md:col-span-2">
                  <div className="text-[11px] tracking-[3px] text-accent-purple mb-4">{s.num}</div>
                  <h2 className="font-display text-2xl text-content-primary mb-4 group-hover:text-gradient transition-all duration-300">{s.title}</h2>
                  <p className="text-content-secondary text-sm leading-relaxed mb-4">{s.desc}</p>
                  <div className="text-xs text-content-muted">For: <span className="text-content-secondary">{s.for}</span></div>
                </div>
                <div>
                  <div className="text-[10px] tracking-[2px] text-content-muted uppercase mb-3">Deliverables</div>
                  <ul className="space-y-2">
                    {s.deliverables.map((d) => (
                      <li key={d} className="flex items-center gap-2 text-xs text-content-secondary">
                        <div className="w-1 h-1 rounded-full bg-accent-purple flex-shrink-0" />
                        {d}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center glass rounded-3xl p-12">
          <h2 className="font-display text-3xl text-content-primary mb-4">Ready to Start?</h2>
          <p className="text-content-secondary mb-8 max-w-md mx-auto">Book a free consultation to discuss your project and get a tailored creative proposal.</p>
          <Link href="/contact" className="btn btn-primary gap-2">
            Book Consultation <ChevronRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
}
