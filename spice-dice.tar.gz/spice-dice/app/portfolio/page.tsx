import type { Metadata } from "next";
import PortfolioSection from "@/components/sections/PortfolioSection";

export const metadata: Metadata = {
  title: "Portfolio — Cinematic Work & Projects",
  description: "Explore Spice Dice's portfolio of short films, branding projects, AI experiments, YouTube content, and social campaigns.",
};

export default function PortfolioPage() {
  return (
    <div className="pt-32 pb-20">
      <div className="section-container mb-0">
        <div className="section-eyebrow mb-6">Portfolio</div>
        <h1 className="font-display text-hero-lg text-content-primary mb-6">SELECTED<br />WORK</h1>
        <p className="text-content-secondary text-lg max-w-xl leading-relaxed">
          A curated collection of cinematic stories, digital campaigns, AI experiments, and creative projects built to inspire and connect.
        </p>
      </div>
      <PortfolioSection />
    </div>
  );
}
