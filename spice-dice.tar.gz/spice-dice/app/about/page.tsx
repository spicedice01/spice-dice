import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Story — From Grass to Grace",
  description: "The story behind Spice Dice — a journey of resilience, creativity, and digital innovation.",
};

const PHASES = [
  {
    phase: "Phase 01",
    year: "The Beginning",
    title: "Curiosity & The First Frame",
    body: "Every great creative journey starts with a single moment of wonder. For Spice Dice, it was the realization that storytelling — through any medium — has the power to change how people see themselves and the world around them. From grassroots beginnings, armed with limited resources but unlimited vision, the journey began.",
  },
  {
    phase: "Phase 02",
    year: "The Discovery",
    title: "Film, Design & Digital Culture",
    body: "The creative world opened up. Film became a language. Design became a tool for meaning. Digital culture became the canvas. Through relentless experimentation — shooting, editing, designing, strategizing — a holistic creative perspective began to take shape. Not just content creation, but creative architecture.",
  },
  {
    phase: "Phase 03",
    year: "The Evolution",
    title: "Building Digital Identity",
    body: "Ideas transformed into campaigns. Campaigns transformed into brands. The ability to combine storytelling with strategy, visuals with data, emotion with technology — this became the signature approach. Projects grew in scale and impact, reaching audiences across Kenya and beyond.",
  },
  {
    phase: "Phase 04",
    year: "The Future",
    title: "AI, Innovation & The Next Chapter",
    body: "Today, Spice Dice stands at the frontier of creative technology — blending AI, cinematic storytelling, and strategic innovation into immersive digital experiences. The mission remains unchanged: to inspire, to create, to build things that matter. The next generation of digital culture starts here.",
  },
];

export default function AboutPage() {
  return (
    <div className="pt-32 pb-20">
      <div className="section-container">
        {/* Hero */}
        <div className="max-w-3xl mb-24">
          <div className="section-eyebrow mb-6">The Story</div>
          <h1 className="font-display text-hero-lg text-gradient mb-8">
            FROM GRASS<br />TO GRACE
          </h1>
          <p className="text-content-secondary text-lg leading-relaxed max-w-xl">
            A cinematic journey from humble beginnings to building world-class digital experiences — powered by resilience, creativity, and the relentless pursuit of innovation.
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">
          <div className="absolute left-0 top-0 bottom-0 w-px bg-gradient-to-b from-accent-purple via-accent-cyan/50 to-transparent hidden md:block" />

          <div className="space-y-24">
            {PHASES.map((phase, i) => (
              <div key={i} className="md:pl-16 relative">
                <div className="hidden md:block absolute -left-2 top-1 w-4 h-4 rounded-full border-2 border-accent-purple bg-bg"
                  style={{ boxShadow: "0 0 16px rgba(124,58,237,0.6)" }}
                />
                <div className="text-[10px] tracking-[3px] text-accent-purple uppercase mb-3">{phase.phase}</div>
                <div className="text-xs text-content-muted mb-2">{phase.year}</div>
                <h2 className="font-display text-3xl text-content-primary mb-5">{phase.title}</h2>
                <p className="text-content-secondary leading-relaxed max-w-2xl">{phase.body}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Positioning statement */}
        <div className="mt-32 glass-purple rounded-3xl p-12 text-center">
          <div className="font-display text-3xl text-gradient mb-4">SPICE DICE</div>
          <p className="text-content-secondary max-w-2xl mx-auto leading-relaxed mb-8">
            A cinematic creative technologist building immersive digital experiences through storytelling, AI, strategy, and visual innovation for the next generation of digital culture.
          </p>
          <Link href="/contact" className="btn btn-primary gap-2">
            Work Together <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
}
