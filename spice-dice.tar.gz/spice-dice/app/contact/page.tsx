import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact — Let's Build Something Powerful",
  description: "Book a consultation, start a project, or just say hello. Spice Dice is available for creative projects worldwide.",
};

export default function ContactPage() {
  return (
    <div className="pt-32 pb-20">
      <div className="section-container">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left */}
          <div>
            <div className="section-eyebrow mb-6">Contact</div>
            <h1 className="font-display text-hero-lg text-gradient mb-8">
              LET&apos;S BUILD<br />SOMETHING<br />POWERFUL
            </h1>
            <p className="text-content-secondary text-base leading-relaxed max-w-md mb-10">
              Whether it&apos;s a brand, campaign, film, digital experience, or future-focused idea — let&apos;s create something meaningful that stands out.
            </p>

            <div className="space-y-4 mb-10">
              {[
                { label: "Email", value: "hello@spicedice.studio", href: "mailto:hello@spicedice.studio" },
                { label: "WhatsApp", value: "+254 (0) 000 000 000", href: "https://wa.me/254000000000" },
                { label: "Location", value: "Nairobi, Kenya · Available Globally", href: null },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-4 p-4 glass rounded-xl">
                  <div className="text-[10px] tracking-[2px] text-accent-purple uppercase w-16 flex-shrink-0">{item.label}</div>
                  {item.href ? (
                    <a href={item.href} className="text-sm text-content-primary hover:text-accent-cyan transition-colors">{item.value}</a>
                  ) : (
                    <span className="text-sm text-content-secondary">{item.value}</span>
                  )}
                </div>
              ))}
            </div>

            <div className="text-xs text-content-muted">
              Typically responds within 24 hours.
            </div>
          </div>

          {/* Right: Form */}
          <div className="card-glass p-8">
            <h2 className="font-display text-2xl text-content-primary mb-6">Send an Inquiry</h2>
            <form className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] tracking-[2px] text-content-muted uppercase block mb-2">Name</label>
                  <input type="text" placeholder="Your name" className="input-cinematic" />
                </div>
                <div>
                  <label className="text-[10px] tracking-[2px] text-content-muted uppercase block mb-2">Email</label>
                  <input type="email" placeholder="your@email.com" className="input-cinematic" />
                </div>
              </div>

              <div>
                <label className="text-[10px] tracking-[2px] text-content-muted uppercase block mb-2">Project Type</label>
                <select className="input-cinematic appearance-none" style={{ background: "rgba(21,21,29,0.8)" }}>
                  <option value="">Select a service...</option>
                  <option>Creative Strategy & Direction</option>
                  <option>AI Integration</option>
                  <option>Video Editing</option>
                  <option>YouTube Strategy</option>
                  <option>Social Media Campaign</option>
                  <option>Digital Marketing</option>
                  <option>Other / Let&apos;s Discuss</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] tracking-[2px] text-content-muted uppercase block mb-2">Budget Range</label>
                <select className="input-cinematic appearance-none" style={{ background: "rgba(21,21,29,0.8)" }}>
                  <option value="">Select budget range...</option>
                  <option>Under $500</option>
                  <option>$500 – $2,000</option>
                  <option>$2,000 – $5,000</option>
                  <option>$5,000 – $10,000</option>
                  <option>$10,000+</option>
                  <option>Let&apos;s discuss</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] tracking-[2px] text-content-muted uppercase block mb-2">Message</label>
                <textarea
                  rows={5}
                  placeholder="Tell me about your project, goals, and vision..."
                  className="input-cinematic resize-none"
                />
              </div>

              <button type="submit" className="btn btn-primary w-full justify-center py-4">
                Send Inquiry
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
