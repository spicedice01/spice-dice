import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "../styles/globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Preloader from "@/components/ui/Preloader";
import CustomCursor from "@/components/ui/CustomCursor";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Spice Dice | Creative Technologist & Digital Media Architect",
    template: "%s | Spice Dice",
  },
  description:
    "Spice Dice is a cinematic creative technologist building immersive digital experiences through storytelling, AI, strategy, and visual innovation.",
  keywords: [
    "Creative Technologist Kenya",
    "Digital Media Architect",
    "Cinematic Video Editor",
    "AI Creative Strategist",
    "Filmmaker Kenya",
    "YouTube Strategist",
    "Creative Director Kenya",
    "Spice Dice",
  ],
  authors: [{ name: "Spice Dice" }],
  creator: "Spice Dice",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://spicedice.studio",
    siteName: "Spice Dice",
    title: "Spice Dice | Creative Technologist & Digital Media Architect",
    description:
      "Building cinematic digital experiences through storytelling, AI, strategy, and innovation.",
  },
  twitter: {
    card: "summary_large_image",
    title: "Spice Dice | Creative Technologist",
    description: "Building cinematic digital experiences through storytelling, AI, and innovation.",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300;400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-bg text-content-primary font-body antialiased">
        <Preloader />
        <CustomCursor />
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
