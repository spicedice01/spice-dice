import type { Metadata } from "next";
import AILabSection from "@/components/sections/AILabSection";

export const metadata: Metadata = {
  title: "AI Lab — Future Creative Systems",
  description: "Exploring the frontier of AI-powered storytelling, creative automation, and digital experience design.",
};

export default function AILabPage() {
  return (
    <div className="pt-32 pb-20">
      <div className="section-container mb-0">
        <div className="section-eyebrow mb-6" style={{ color: "#00D4FF" }}>
          <span className="w-6 h-px bg-accent-cyan inline-block" />
          AI Lab
        </div>
        <h1 className="font-display text-hero-lg text-content-primary mb-6">
          FUTURE<br />SYSTEMS
        </h1>
        <p className="text-content-secondary text-lg max-w-xl leading-relaxed">
          Exploring the frontier of storytelling, creativity, and digital innovation through artificial intelligence. Where human vision meets machine intelligence.
        </p>
      </div>
      <AILabSection />
    </div>
  );
}
