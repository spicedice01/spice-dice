import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Blog — Insights on AI, Film & Digital Culture",
  description: "Thought leadership on AI creativity, filmmaking, YouTube strategy, digital storytelling, and the creator economy.",
};

const POSTS = [
  { slug: "future-of-ai-storytelling", title: "The Future of AI-Powered Storytelling", category: "AI Creativity", date: "May 2026", readTime: 6, excerpt: "How artificial intelligence is reshaping the way we conceive, create, and distribute cinematic narratives across digital platforms." },
  { slug: "youtube-retention-systems", title: "Building YouTube Retention Systems That Actually Work", category: "YouTube Strategy", date: "April 2026", readTime: 8, excerpt: "A data-informed breakdown of the content architecture patterns that consistently drive audience retention and channel growth." },
  { slug: "cinematic-branding", title: "Why Your Brand Needs Cinematic Storytelling", category: "Storytelling", date: "March 2026", readTime: 5, excerpt: "Brands that tell stories — real, cinematic, emotionally resonant stories — build audiences, not just customers." },
  { slug: "creator-economy-2026", title: "The Creator Economy in 2026: What Changed", category: "Creator Economy", date: "February 2026", readTime: 7, excerpt: "AI, short-form video, and new monetization models have fundamentally restructured what it means to build a creative business." },
  { slug: "from-grass-to-grace", title: "From Grass to Grace: Building a Creative Brand with Nothing", category: "Storytelling", date: "January 2026", readTime: 10, excerpt: "A personal essay on starting creative work with limited resources, surviving self-doubt, and building something real." },
  { slug: "ai-tools-filmmaking", title: "The AI Tools Every Filmmaker Needs in 2026", category: "Filmmaking", date: "December 2025", readTime: 9, excerpt: "From pre-production to post, these are the AI tools that are genuinely transforming how independent filmmakers work." },
];

const CATEGORIES = ["All", "AI Creativity", "YouTube Strategy", "Storytelling", "Filmmaking", "Creator Economy", "Digital Branding"];

const catColor: Record<string, string> = {
  "AI Creativity": "tag-cyan",
  "YouTube Strategy": "tag-purple",
  "Storytelling": "tag-purple",
  "Filmmaking": "tag-purple",
  "Creator Economy": "tag-cyan",
  "Digital Branding": "tag-purple",
};

export default function BlogPage() {
  return (
    <div className="pt-32 pb-20">
      <div className="section-container">
        <div className="section-eyebrow mb-6">Insights</div>
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-8 mb-16">
          <h1 className="font-display text-hero-lg text-content-primary">BLOG</h1>
          <p className="text-content-secondary text-sm max-w-xs leading-relaxed">
            Thought leadership on AI creativity, filmmaking, digital storytelling, and the future of the creator economy.
          </p>
        </div>

        {/* Category filters */}
        <div className="flex flex-wrap gap-2 mb-12">
          {CATEGORIES.map((cat) => (
            <button key={cat} className={`px-4 py-2 rounded-full text-xs font-medium tracking-wide transition-all glass text-content-secondary hover:text-content-primary border border-border-subtle ${cat === "All" ? "bg-accent-purple text-white border-accent-purple" : ""}`}>
              {cat}
            </button>
          ))}
        </div>

        {/* Featured post */}
        <div className="card-glass rounded-3xl p-10 mb-6 group cursor-pointer">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <span className={`tag ${catColor[POSTS[0].category] || "tag-purple"} text-[10px]`}>{POSTS[0].category}</span>
                <span className="text-xs text-content-muted">Featured</span>
              </div>
              <h2 className="font-display text-3xl text-content-primary mb-4 group-hover:text-gradient transition-all duration-300">
                {POSTS[0].title}
              </h2>
              <p className="text-content-secondary text-sm leading-relaxed mb-6">{POSTS[0].excerpt}</p>
              <div className="flex items-center gap-4">
                <span className="text-xs text-content-muted">{POSTS[0].date}</span>
                <span className="text-xs text-content-muted">·</span>
                <span className="text-xs text-content-muted">{POSTS[0].readTime} min read</span>
                <Link href={`/blog/${POSTS[0].slug}`} className="text-xs text-accent-purple flex items-center gap-1 hover:text-accent-cyan transition-colors ml-auto">
                  Read <ArrowUpRight size={12} />
                </Link>
              </div>
            </div>
            <div className="h-52 rounded-2xl bg-gradient-to-br from-accent-purple/30 to-accent-cyan/20 hidden md:block" />
          </div>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {POSTS.slice(1).map((post) => (
            <Link key={post.slug} href={`/blog/${post.slug}`} className="card-glass p-6 group block">
              <div className="h-32 rounded-xl bg-gradient-to-br from-bg-elevated to-bg-surface mb-5" />
              <span className={`tag ${catColor[post.category] || "tag-purple"} text-[10px] mb-3 inline-block`}>{post.category}</span>
              <h3 className="font-display text-lg text-content-primary mb-3 group-hover:text-gradient transition-all duration-300">
                {post.title}
              </h3>
              <p className="text-content-secondary text-xs leading-relaxed mb-4">{post.excerpt}</p>
              <div className="flex items-center gap-3 text-xs text-content-muted">
                <span>{post.date}</span>
                <span>·</span>
                <span>{post.readTime} min</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
