import Link from "next/link";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <div className="font-display text-[120px] text-gradient leading-none mb-6">404</div>
        <h1 className="font-display text-3xl text-content-primary mb-4">Page Not Found</h1>
        <p className="text-content-secondary mb-8 max-w-sm mx-auto">
          This page doesn&apos;t exist in our digital universe — yet.
        </p>
        <Link href="/" className="btn btn-primary">Return Home</Link>
      </div>
    </div>
  );
}
