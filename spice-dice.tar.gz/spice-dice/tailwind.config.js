/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./sections/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        bg: {
          DEFAULT: "#0B0B0F",
          surface: "#15151D",
          elevated: "#1C1C27",
        },
        accent: {
          purple: "#7C3AED",
          "purple-light": "#9F67FF",
          "purple-dark": "#5B21B6",
          cyan: "#00D4FF",
          "cyan-light": "#67E8FF",
          "cyan-dim": "#00A8CC",
        },
        content: {
          primary: "#F5F5F5",
          secondary: "#A1A1AA",
          muted: "#52525B",
          dim: "#3F3F46",
        },
        border: {
          subtle: "rgba(255,255,255,0.06)",
          DEFAULT: "rgba(255,255,255,0.10)",
          accent: "rgba(124,58,237,0.25)",
          cyan: "rgba(0,212,255,0.20)",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      fontSize: {
        "hero-xl": ["clamp(3.5rem, 8vw, 7rem)", { lineHeight: "0.95", letterSpacing: "-0.02em" }],
        "hero-lg": ["clamp(2.5rem, 5vw, 5rem)", { lineHeight: "1.0", letterSpacing: "-0.02em" }],
        "section": ["clamp(2rem, 4vw, 3.5rem)", { lineHeight: "1.1", letterSpacing: "-0.015em" }],
        "card-lg": ["clamp(1.25rem, 2vw, 1.75rem)", { lineHeight: "1.2" }],
      },
      spacing: {
        section: "120px",
        "section-sm": "80px",
        "section-mobile": "64px",
      },
      maxWidth: {
        site: "1440px",
        content: "880px",
        narrow: "640px",
      },
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "gradient-conic": "conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))",
        "gradient-brand": "linear-gradient(135deg, #7C3AED, #00D4FF)",
        "gradient-purple": "linear-gradient(135deg, #7C3AED, #5B21B6)",
        "noise": "url('/noise.svg')",
      },
      animation: {
        "float": "float 6s ease-in-out infinite",
        "float-slow": "float 9s ease-in-out infinite",
        "pulse-glow": "pulseGlow 3s ease-in-out infinite",
        "grain": "grain 0.5s steps(1) infinite",
        "shimmer": "shimmer 2.5s linear infinite",
        "orbit": "orbit 20s linear infinite",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-16px)" },
        },
        pulseGlow: {
          "0%, 100%": { opacity: "0.5", transform: "scale(1)" },
          "50%": { opacity: "1", transform: "scale(1.05)" },
        },
        grain: {
          "0%, 100%": { transform: "translate(0,0)" },
          "10%": { transform: "translate(-2%,-3%)" },
          "30%": { transform: "translate(3%,-1%)" },
          "50%": { transform: "translate(-1%,2%)" },
          "70%": { transform: "translate(2%,1%)" },
          "90%": { transform: "translate(-3%,3%)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        orbit: {
          "0%": { transform: "rotate(0deg) translateX(150px) rotate(0deg)" },
          "100%": { transform: "rotate(360deg) translateX(150px) rotate(-360deg)" },
        },
      },
      backdropBlur: {
        xs: "2px",
      },
      transitionTimingFunction: {
        "cinematic": "cubic-bezier(0.25, 0.1, 0.25, 1)",
        "spring": "cubic-bezier(0.34, 1.56, 0.64, 1)",
        "ease-out-expo": "cubic-bezier(0.16, 1, 0.3, 1)",
      },
    },
  },
  plugins: [],
};
